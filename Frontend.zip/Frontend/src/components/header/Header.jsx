import React from 'react'
import './style.css'

function Header() {
  return (
    <div className="main__container">
      <div className='container '>
      <div className="row ">
        <div className="col-10 offset-1 ">
        <h1 className='main__heading'>Well come to E-Diabetes Prediction</h1>
        <p className='main__text'>this is ML based model that pridict the user Diabetes!!!!</p>
        </div>
      </div>
    </div>
    </div>
    
  )
}

export default Header
