import React, { useState } from 'react';
import { Favorite, Bloodtype, MonitorWeight, AccessTime, Numbers, Science, Face, Elderly, ErrorOutline } from '@mui/icons-material';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Detail.css';
import Result from '../result/Result';

function Detail() {
  const [formData, setFormData] = useState({
    Pregnancies: '',
    Glucose: '',
    BloodPressure: '',
    SkinThickness: '',
    Insulin: '',
    BMI: '',
    DiabetesPedigreeFunction: '',
    Age: '',
  });

  const [error, setError] = useState('');
  const [result, setResult] = useState('');
  const [modalVisible, setModalVisible] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
    setResult('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const isEmpty = Object.values(formData).some((val) => val === '');
    if (isEmpty) {
      setError('Please fill out all fields!');
      return;
    }

    try {
      const res = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      setResult(data.prediction);
      setModalVisible(true);
    } catch (err) {
      setError('Could not connect to the server!');
    }
  };

  const renderInput = (label, icon, name, placeholder) => (
    <div className="mb-4 col-md-6">
      <label className="form-label fw-semibold">{label}</label>
      <div className="input-group shadow-sm">
        <span className="input-group-text bg-light">{icon}</span>
        <input
          type="number"
          name={name}
          className="form-control"
          placeholder={placeholder}
          value={formData[name]}
          onChange={handleChange}
        />
      </div>
    </div>
  );

  const closeModal = () => setModalVisible(false);

  return (
    <div className="container mt-5 mb-5">
      {!modalVisible && (
        <div className="card shadow-lg p-5 rounded-5 bg-white">
          <h2 className="text-center fw-bold mb-4" style={{ color: '#2c3e50' }}>
            🩺 Diabetes Prediction Form
          </h2>
          <p className="text-center text-muted mb-4">
            Please fill in your medical information below to check your diabetes risk.
          </p>

          {error && (
            <div className="alert alert-danger d-flex align-items-center" role="alert">
              <ErrorOutline className="me-2" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="row">
              {renderInput('Pregnancies', <Numbers />, 'Pregnancies', 'Number of Pregnancies')}
              {renderInput('Glucose Level', <Bloodtype />, 'Glucose', 'Glucose Level')}
              {renderInput('Blood Pressure', <MonitorWeight />, 'BloodPressure', 'Blood Pressure')}
              {renderInput('Skin Thickness', <AccessTime />, 'SkinThickness', 'Skin Thickness')}
              {renderInput('Insulin', <Science />, 'Insulin', 'Insulin')}
              {renderInput('BMI', <Face />, 'BMI', 'Body Mass Index')}
              {renderInput('Diabetes Pedigree', <Elderly />, 'DiabetesPedigreeFunction', 'Diabetes Pedigree Function')}
              {renderInput('Age', <Elderly />, 'Age', 'Your Age')}
            </div>

            <div className="d-grid mt-4">
              <button className="btn btn-primary fw-semibold fs-5 py-2 rounded-pill" type="submit">
                Predict Now
              </button>
            </div>
          </form>
        </div>
      )}

      {modalVisible && <Result result={result} closeModal={closeModal} />}
    </div>
  );
}

export default Detail;
