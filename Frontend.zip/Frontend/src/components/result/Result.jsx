import React from 'react';
import happy_person from '../../assets/happy.png';
import sad_person from '../../assets/sad.png';
import './Result.css';

function Result({ result, closeModal }) {
  return (
    <div className="container mt-5 mb-5">
      <div className="card shadow-lg p-5 rounded-5 bg-white result-card">
        <h2 className="text-center fw-bold mb-4 result-title">
          🩺 Diabetes Prediction Result
        </h2>

        {result && (
          <div className={`alert ${result === 'Diabetic' ? 'alert-danger' : 'alert-success'} d-flex align-items-center result-alert`}>
            <strong>Prediction:</strong> {result === 'Diabetic' ? 'You are at risk of diabetes!' : 'You are not at risk of diabetes!'}
          </div>
        )}

        <div className="text-center">
          {result === 'Diabetic' ? (
            <img src={sad_person} alt="Sad Person" className="result-icon sad-icon animate-sad" />
          ) : (
            <img src={happy_person} alt="Happy Person" className="result-icon happy-icon animate-happy" />
          )}
        </div>

        <div className="text-center mt-4">
          <button className="btn btn-secondary" onClick={closeModal}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default Result;
