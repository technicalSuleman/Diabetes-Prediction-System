import React from 'react'
import Header from '../components/header/Header'
import Detail from '../Components/form/Detail'

function Main() {
  return (
    <div>
      <Header />
      <Detail />
    </div>
  )
}

export default Main
